<?php
$db_host = "databasepocketpay.cojzshwn6tga.ap-south-1.rds.amazonaws.com";
$db_user = "adminpktpay";
$db_pass = "24cbNvSfUoZtSnHliUlI";
$db_name = "armentum_2";
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name) or die("Connection failed!");
if ($conn->connect_errno) {
    die("Connection Failed");
}
